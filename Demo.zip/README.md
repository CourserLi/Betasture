1. 请联网
2. 请将 `Betasture.exe` 和 `vlc` 文件放置在同一目录下【就是现在这样】